import { createClient } from "@supabase/supabase-js";
import type { Database } from "./types";

const SUPABASE_URL = "https://wldwotlenwxurfixewxq.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndsZHdvdGxlbnd4dXJmaXhld3hxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ2NzU1NzEsImV4cCI6MjEwMDI1MTU3MX0.fTtUmGC_LGWzK0I83JmkmafNW8UakaNDV0ZHoTc5jOo";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY);
